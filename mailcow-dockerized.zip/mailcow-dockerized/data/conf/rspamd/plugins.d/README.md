This is where you should copy any rspamd custom module
